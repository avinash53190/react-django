# todo_app_react
Here is a robust todo app built with React Js, this is mainly for beginners learning React Js 
